package com.example.project3cs478;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import android.widget.Button;
import android.widget.Toast;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button buttonAttract = findViewById(R.id.button);
        Button buttonRestaurants = findViewById(R.id.button2);

        buttonAttract.setOnClickListener(v -> {
            Toast.makeText(this, "Opening Attractions", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent("ATTRACTIONS");
            intent.addCategory(Intent.CATEGORY_DEFAULT);
            startActivity(intent);  // directly opens AttractionActivity
        });

        buttonRestaurants.setOnClickListener(v -> {
            Toast.makeText(this, "Opening Restaurants", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent("RESTAURANTS");
            intent.addCategory(Intent.CATEGORY_DEFAULT);
            startActivity(intent);  // directly opens RestaurantActivityG
        });
    }







}